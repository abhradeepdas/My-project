var yourNavigation = $(".mx-background-top-linear");
stickyDiv = "sticky";
yourHeader = $(".topbar").height();

$(window).scroll(function() {
  if ($(this).scrollTop() > yourHeader) {
    yourNavigation.addClass(stickyDiv);
  } else {
    yourNavigation.removeClass(stickyDiv);
  }
});
