$(document).ready(function(){
    $("#openme1").click(function(){
        $(".open_me1").hide();
        $(".close_me1").show();
       
        
    });
    $("#closeme1").click(function(){
         $(".open_me1").show(250);
        $(".close_me1").hide();
    });
    
     $("#openme2").click(function(){
        $(".open_me2").hide();
        $(".close_me2").show();
        
    });
    $("#closeme2").click(function(){
         $(".open_me2").show(250);
        $(".close_me2").hide();
    });
});
      
      
      
      
      
      
      
      